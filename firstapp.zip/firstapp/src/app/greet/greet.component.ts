import { Component } from '@angular/core';

@Component({
  selector: 'app-greet',
  templateUrl: './greet.component.html',
  styleUrl: './greet.component.css'
})
export class GreetComponent {

  msg:string = "Happy Learning (greet)";
  dob:Date = new Date();
}
