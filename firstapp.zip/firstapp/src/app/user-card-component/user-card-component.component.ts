import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-user-card-component',
  templateUrl: './user-card-component.component.html',
  styleUrl: './user-card-component.component.css'
})
export class UserCardComponentComponent {
  @Input()
   user!: { name: string; email?: string; profilePicture: string };
  
  
  public addUser(uname:HTMLInputElement, email:HTMLInputElement, ppurl:HTMLInputElement):void{
    this.user = {
        name: uname.value,
        email: email.value,
        profilePicture: ppurl.value
    }

    uname.value = '';
    email.value = '';
    ppurl.value = '';
  }
}
