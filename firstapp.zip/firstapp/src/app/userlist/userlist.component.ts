import { Component } from '@angular/core';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrl: './userlist.component.css'
})
export class UserlistComponent {

  userNames:Array<string> = ['Eshwari','Ankita','Priyanka','Nisha']
  message: string = '';

  addUser(input: HTMLInputElement): void {
    const name = input.value;
    if (name) {
      this.userNames.push(name);
      this.message = 'User added!';

      input.value = '';

      setTimeout(() => {
        this.message = '';
      }, 2000);
    }
}
}

