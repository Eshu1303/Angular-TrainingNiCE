import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'wish'
})
export class WishPipe implements PipeTransform {

  transform(value: string, op:string): string {
    if(op == 'en')
      return 'Hello ' + value;
    if(op == 'sp')
      return 'HOLA ' + value;

    return 'HI ' + value;
  }

}
