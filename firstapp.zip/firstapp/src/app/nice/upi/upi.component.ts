import { Component } from '@angular/core';

@Component({
  selector: 'app-upi',
  templateUrl: './upi.component.html',
  styleUrl: './upi.component.css'
})
export class UpiComponent {

}
