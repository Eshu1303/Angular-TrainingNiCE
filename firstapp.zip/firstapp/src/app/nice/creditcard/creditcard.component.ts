import { Component } from '@angular/core';

@Component({
  selector: 'app-creditcard',
  templateUrl: './creditcard.component.html',
  styleUrl: './creditcard.component.css'
})
export class CreditcardComponent {

}
