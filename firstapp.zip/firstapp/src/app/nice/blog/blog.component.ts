import { Component } from '@angular/core';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrl: './blog.component.css'
})
export class BlogComponent {
  comments:Array<string> = ['Nice..', 'Good Blog..'];

  public process(cmt:string):void{
    this.comments.push(cmt);
  }
}
