import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrl: './comment.component.css'
})
export class CommentComponent {

  @Output()
  private send:EventEmitter<string> = new EventEmitter();
  public add(cmt:HTMLInputElement):void{
    this.send.emit(cmt.value);
    cmt.value = '';
  }
}
