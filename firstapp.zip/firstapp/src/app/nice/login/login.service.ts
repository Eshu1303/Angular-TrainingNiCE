import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { 

  }

  public check(login:string, password:string): boolean{
    
    if(login == 'Jack' && password == '123')
    {
      sessionStorage.setItem('user', login);
      return true;
    }
      
    else
      return false
  }
}
