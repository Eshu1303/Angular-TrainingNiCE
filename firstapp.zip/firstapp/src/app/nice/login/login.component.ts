import { Component, inject, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {

  private ls: LoginService = inject(LoginService);
  private rr: Router = inject(Router);

  msg:string ='';
  constructor(){
  }

  ngOnInit(): void {
    if(sessionStorage.getItem('user') != null)
    {
      alert('session active...');
      this.rr.navigate(['']);
    }
  }
  public doLogin(lg:HTMLInputElement, pw:HTMLInputElement):void{
    
    if(this.ls.check(lg.value,pw.value))
      this.msg='Welcome ' +lg.value;
    else
      this.msg = 'Inavlid Login/Password';

  }
}
