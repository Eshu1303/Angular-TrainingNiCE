import { Component, OnDestroy, OnInit } from '@angular/core';
import { TopicService } from './topics.service';

@Component({
  selector: 'app-topics',
  templateUrl: './topics.component.html',
  styleUrl: './topics.component.css'
})
export class TopicsComponent implements OnInit, OnDestroy{
  tps:Array<string> = [];
  //constructor injection
  constructor(private ts:TopicService){
    // let ts:TopicService = new TopicService(); no need to create new instances everytime.
    this.tps = ts.getTopics();
  }

  ngOnInit(): void {
    this.tps = this.ts.getTopics();
  }

  ngOnDestroy(): void {
    this.tps =[];
  }

  public addTopic(tp:HTMLInputElement):void{
    //this.tps.push(tp.value);
    //this.tps = [...this.tps,tp.value] no need to do this way when we have service.
    this.ts.addTopic(tp.value);
    tp.value= '';

  }
}
