import { Injectable } from "@angular/core";

@Injectable(
    {providedIn: 'root'}
)

export class TopicService{
    private topics: Array<string> = ['Java', 'Angular', 'React'];
    public getTopics(): Array<string>{
        return this.topics;
    }
    public addTopic(tp:string){
        this.topics.push(tp);
    }
}
