import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { GreetComponent } from './greet/greet.component';
import { TopicsComponent } from './topics/topics.component';
import { UserCardComponentComponent } from './user-card-component/user-card-component.component';
import { NiceModule } from './nice/nice.module';
import { HighlightDirective } from './highlight.directive';
import { WishPipe } from './wish.pipe';
import { RouterModule, Routes } from '@angular/router';
import { BlogComponent } from './nice/blog/blog.component';
import { LoginComponent } from './nice/login/login.component';
import { UserlistComponent } from './userlist/userlist.component';
import { SearchComponent } from './search/search.component';
import { MasksensitivePipe } from './masksensitive.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';

const routes:Routes = [
  {path:'',component:HomeComponent, title:'Home'},
  {path:'greet', component:GreetComponent,title:'Greet'},
  {path:'topics', component:TopicsComponent,title:'Topics'},
  {path:'blog',component:BlogComponent,title:'Blog'},
  {path:'login',component:LoginComponent,title:'Login'},
  {path:'user-card', component:UserCardComponentComponent, title:'UserCard'},
  {path:'user-list', component:UserlistComponent, title:'UserList'},
  {path:'search', component:SearchComponent, title:'SearchItem'},
  {path:'**',redirectTo: ''}
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    GreetComponent,
    TopicsComponent,
    UserCardComponentComponent,
    HighlightDirective,
    WishPipe,
    UserlistComponent,
    SearchComponent,
    MasksensitivePipe,
    ParentComponent,
    ChildComponent
    
  ],
  imports: [
    BrowserModule,
    NiceModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
