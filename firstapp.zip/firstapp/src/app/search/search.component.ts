import { Component } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent {
  items:Array<string> =['Apple', 'Banana', 'Mango', 'Cherry', 'Watermelon', 'Apples', 'Mangoes'];

  filteredItems: Array<string> = [...this.items];

  filteredList(searchInput:HTMLInputElement):void{
    const query = searchInput.value.toLowerCase();
    this.filteredItems = this.items.filter(item => item.toLowerCase().includes(query));
  }
  

}
