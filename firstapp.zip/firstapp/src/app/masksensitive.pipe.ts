import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'masksensitive'
})
export class MasksensitivePipe implements PipeTransform {

  transform(value: string, vChar: number=4): string {
    if(!value) 
      return '';
    const maskedLength = value.length - vChar;
    const mask = '*'.repeat(maskedLength);
    const visible = value.slice(-vChar);
    return mask+visible;
  }

}
