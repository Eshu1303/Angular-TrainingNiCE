import { Component } from '@angular/core';
import { ChildComponent } from '../child/child.component';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrl: './parent.component.css',
})
export class ParentComponent {

  user = {
    name: 'Eshwari Rampoore',
    age: 22,
    email: 'eshwari@gmail.com'
  };

   updateUser() {
    this.user = {
      ...this.user,
      age: this.user.age + 1 // increment age
    };
  }
}
