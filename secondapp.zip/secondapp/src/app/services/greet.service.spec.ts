import { GreetService } from "./greet.service";

let gs: GreetService | any;

beforeAll(()=>{
    console.log('starting test....');
})
beforeEach(() => {
    gs = new GreetService();
});
describe('test suite for greetservice', () => {
    it('greet() should return Hello <name>', () => {
        expect(gs.greet('John')).toBe('Hello John');
        expect(gs.greet('Jack')).toBe('Hello Jack');
    });
    it('greet() should return Hello Guest', () => {
        expect(gs.greet('')).toBe('Hello Guest');
    });
afterEach(() => {
      gs = null;
})

beforeAll(()=>{
    console.log('ending test....');
})
});