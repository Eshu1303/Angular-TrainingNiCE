import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SignupComponent } from './sign-up/sign-up.component';
import { UsersComponent } from './users/users.component';
import { HttpClientModule } from '@angular/common/http';
import { CarsComponent } from './cars/cars.component';
import { AppRoutingModule } from "../app-routing.module";
import { DetailsComponent } from './details/details.component';
import { NameplateComponent } from './nameplate/nameplate.component';



@NgModule({
  declarations: [
    HomeComponent,
    SignInComponent,
    SignupComponent,
    UsersComponent,
    CarsComponent,
    DetailsComponent,
    NameplateComponent
  ],
  exports :[
    HomeComponent,
    SignInComponent,
    SignupComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule
]
})
export class NiceModule { }
