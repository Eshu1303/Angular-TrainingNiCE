import { Component, computed, Signal, signal, WritableSignal } from '@angular/core';

@Component({
  selector: 'app-nameplate',
  templateUrl: './nameplate.component.html',
  styleUrl: './nameplate.component.css'
})
export class NameplateComponent {

  fname:WritableSignal<string>= signal('');
  mname:WritableSignal<string>=signal('');
  lname:WritableSignal<string>=signal('');
  dname:Signal<string>=computed(()=> this.lname()+" "+ this.fname()+" "+this.mname());

  // public show(){
  //   this.dname = this.lname+ " "+ this.fname+" "+this.mname;
  // }
 

}
