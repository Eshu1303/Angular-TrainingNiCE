import { Component, OnChanges, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Car } from '../cars/car.mode';
import { CarService } from '../cars/car.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrl: './details.component.css'
})
export class DetailsComponent {
  id: string = '';
  car: Car = { id: '', make: '', model: '', variant: '' };
  constructor(private ar: ActivatedRoute, private cs: CarService) {
    ar.params.subscribe(p => {
      this.id = p['id'];
       this.cs.getCar(this.id).subscribe(res => {
       this.car = res[0];
    });
    });
  }
  
}
