import { Observable } from "rxjs";
import { Car } from "./car.mode";
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
@Injectable({
    providedIn: 'root'
})
export class CarService {
    private url: string = "http://localhost:3000/cars";
    constructor(private http: HttpClient) {
    }
    public getCars(): Observable<Array<Car>> {
        return this.http.get<Array<Car>>(this.url);
    }
    public addCar(id: string, make: string, model: string, variant: string): Observable<Car> {
        let c: Car = { id: id, make: make, model: model, variant: variant };
        return this.http.post<Car>(this.url, c);
    }
    public delCar(id: string): Observable<Car> {
        return this.http.delete<Car>(this.url + "/" + id);
    }
     public getCar(id:string): Observable<Array<Car>> {
        return this.http.get<Array<Car>>(this.url+"/"+id);
    }
}