export interface Car {
    id:string;
    make:string;
    model:string;
    variant:string;
}