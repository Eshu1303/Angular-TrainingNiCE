import { Component, OnInit } from '@angular/core';
import { Car } from './car.mode';
import { CarService } from './car.service';
import { CssSelector } from '@angular/compiler';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrl: './cars.component.css'
})
export class CarsComponent implements OnInit {
  cars: Array<Car> = [];
  constructor(private cs: CarService) {
  }
  load(){
    this.cs.getCars().subscribe(res => {
      this.cars = res;
    });
  }
  ngOnInit(): void {
      this.load();
  }
  public addCar(idref: HTMLInputElement, makeref: HTMLInputElement, modelref: HTMLInputElement, variantref: HTMLInputElement): void {
    this.cs.addCar(idref.value, makeref.value, modelref.value, variantref.value).subscribe(res=>{
    alert(res.make  + " Saved") ;
    idref.value='';
    makeref.value='';
    modelref.value='';
    variantref.value='';
    this.load(); 
    });
  }
  public delCar(id:string):void{
   this.cs.delCar(id).subscribe(res=>{
     alert(res.make  + " deleted..") ;
     this.load();
   });
  }
}
