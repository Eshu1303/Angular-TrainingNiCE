import { Component } from '@angular/core';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrl: './sign-in.component.css'
})
export class SignInComponent {
  login: string = ''
  password: string = ''
  msg: string = '';
  public doSignIn(): void {
    if (this.login == "John" && this.password == "123")
      this.msg = 'Welcome ' + this.login;
    else
      this.msg = "Invalid login/password";
  }
}
