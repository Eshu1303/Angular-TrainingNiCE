import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { User } from "./user.model";
import { HttpClient } from "@angular/common/http";
@Injectable({
    providedIn:'root'
})
export class UserService {
     constructor(private http:HttpClient){
      }
private url ="https://jsonplaceholder.typicode.com/users";
    public getUsers():Observable<Array<User>> {
      return this.http.get<Array<User>>(this.url);
    }
}