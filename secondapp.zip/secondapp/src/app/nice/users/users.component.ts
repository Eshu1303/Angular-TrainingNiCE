import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { User } from './user.model';
import { UserService } from './user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrl: './users.component.css'
})
export class UsersComponent {
  data:Array<User> =[];

  constructor(private us:UserService){
  }
  public getData():void{
    this.us.getUsers().subscribe((res)=>{
      this.data=res;
    });
  }
}
