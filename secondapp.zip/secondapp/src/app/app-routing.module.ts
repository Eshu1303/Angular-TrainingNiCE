import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './nice/home/home.component';
import { SignInComponent } from './nice/sign-in/sign-in.component';
import { SignupComponent } from './nice/sign-up/sign-up.component';
import { UsersComponent } from './nice/users/users.component';
import { CarsComponent } from './nice/cars/cars.component';
import { DetailsComponent } from './nice/details/details.component';
import { NameplateComponent } from './nice/nameplate/nameplate.component';

const routes: Routes = [
  { path: '', component: HomeComponent, title: 'Home' },
  { path: 'signin', component: SignInComponent, title: 'SignIn' },
  { path: 'signup', component: SignupComponent, title: 'SignUp' },
  { path: 'users', component: UsersComponent, title: 'Users' },
  {
    path: 'cars', component: CarsComponent, title: 'Cars', children: [
      { path: 'details/:id', component: DetailsComponent, title: 'Cars' }
    ]
  },
  {path: 'nameplate', component: NameplateComponent, title: 'NamePlate'},

  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
