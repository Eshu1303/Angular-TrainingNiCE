let cars = [
    {id:'C1', make: 'Hyundai', model: 'Grand i10', variant: 'Sports' },
    {id:'C2', make: 'Hyundai', model: 'Grand i20', variant: 'Active' },
    {id:'C3', make: 'Maruti', model: 'Ciaz', variant: 'Hybrid' },
];

module.exports = cars;
