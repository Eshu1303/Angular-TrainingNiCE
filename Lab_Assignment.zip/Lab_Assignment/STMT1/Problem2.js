const PI = 3.14;
//PI = 3.14159;
console.log(PI);