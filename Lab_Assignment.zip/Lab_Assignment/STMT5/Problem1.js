//Convert the following function to an arrow function: 
let multiply = (a, b)=> {
 return a * b;
}

console.log(multiply(10,20));