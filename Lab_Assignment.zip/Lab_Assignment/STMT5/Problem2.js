// Fix the this issue in the following code using an arrow function: 
const person = {
 name: "Alice",
 greet: function() {
 setTimeout(()=> {
 console.log(`Hello, ${this.name}!`);
 }, 1000);
 }
};
person.greet(); // Should log "Hello, Alice!