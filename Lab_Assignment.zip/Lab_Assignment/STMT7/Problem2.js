// Simulate an API call that may fail. If successful, resolve with { data: "Fetched data" }. 
// If failed, reject with "Error fetching data".

function apiCall() {
    let p = new Promise((resolve, reject) => {
        const success = Math.random > 0.5;
        if(success)
            resolve({data: "Fetched data"});
        else
            reject("Error fetching data");

    });
    return p;
}

apiCall().then((successMsg)=>console.log(successMsg)).catch((errorMsg)=>console.log(errorMsg));