// Create a Promise that resolves after 2 seconds with the message "Success!" and log it. 

function msg() {
    let p = new Promise((resolve, reject) => {
        
    setTimeout(()=>{
        resolve('Success!')
    },2000);
    });
    return p;
}

msg().then((message)=>{
    console.log(message);
});

