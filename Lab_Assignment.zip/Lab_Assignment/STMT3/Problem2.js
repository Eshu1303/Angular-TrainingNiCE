// Create a function createUser(name, age, isAdmin) where isAdmin defaults to false.

function createUser(name, age, isAdmin=false){
    console.log(`User created for Name = ${name}, Age = ${age}, Admin = ${isAdmin}`);
}

createUser("eshwari",21,true);
createUser("esh",20)