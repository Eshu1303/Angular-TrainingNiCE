// Write a function greet(name, greeting) where greeting defaults to "Hello" if not provided. 
function greet(name, greeting = "Hello"){
    console.log(`Good Morning ${name} ${greeting} `)
}

greet("Eshwari")
greet("Eshwari", "Happy Holidays!!")