// Create a Car class with properties brand and speed, and a method accelerate() that increases speed by 10. 

class Car{
    constructor(brand,speed){
        this.brand= brand;
        this.speed= speed;
    }
    accelerate(){
        this.speed+=10;
        console.log(`Brand : ${this.brand}, Speed: ${this.speed}`);
    }
}
var c = new Car('BMW',1000);
c.accelerate();

export default Car;