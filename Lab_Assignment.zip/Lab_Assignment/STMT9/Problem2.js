import Car from "./Problem1.js";

//Extend the Car class to create an ElectricCar class with an additional battery property and a charge() method. 
class ElectricCar extends Car {
    constructor(brand, speed, battery) {
        super(brand,speed);
        this.battery=battery;
    }
    charge(){
        this.battery+= 1000;
        console.log(`Name: ${this.brand} Speed: ${this.speed} Battery: ${this.battery}`);  
    }
}

var cc = new ElectricCar('Mercedes',100,10);
cc.accelerate();
cc.charge();