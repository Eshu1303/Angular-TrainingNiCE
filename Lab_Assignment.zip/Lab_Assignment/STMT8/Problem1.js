//Rewrite the following Promise-based function using async/await: 
// function fetchData() {
//  return new Promise(resolve => {
//  setTimeout(() => resolve("Data received!"), 1000);
//  });
// }
// fetchData().then(data => console.log(data));


async function fetchData() {
  return new Promise(resolve => {
    setTimeout(() => resolve("Data received!"), 1000);
  });
}

async function main() {
  const data = await fetchData();
  console.log(data); 
}

main();