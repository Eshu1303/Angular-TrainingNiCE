// Write an async function that fetches user data 
// from https://jsonplaceholder.typicode.com/users/1 and logs the name. 


async function getUserData() {
  const res = await fetch("http://jsonplaceholder.typicode.com/users/1");
  const user = await res.json();
  console.log(user.name);
}

getUserData();