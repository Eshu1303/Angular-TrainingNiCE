/*
4. HTTP Request and Data Mapping
Using RxJS, create an Observable from a HTTP GET request to the endpoint
https://jsonplaceholder.typicode.com/users. Once the response is received, use
operators to parse the JSON response body, extract an array of user objects, and map
that array to a new array containing only the username property from each user.
Subscribe to this final Observable and log the resulting list of usernames.
*/
