/*
3. Interval Emission with Limited Take 
Utilize the interval creation function from RxJS to generate an Observable that emits an 
incrementing integer (starting from 0) every 1000 milliseconds (1 second). Use an 
operator to limit the total number of emissions to only the first 5 values before the 
Observable automatically completes. 
*/

import { interval, take } from "rxjs";



let nums = interval(1000).pipe(take(5));

nums.subscribe({
    next: (res) =>{
        console.log(res);
    },
    complete:()=> {
        console.log("Completed!!!");
        
    },
})