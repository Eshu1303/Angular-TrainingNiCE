"use strict";
/*
1. Basic Observable Creation and Subscription
Using RxJS, instantiate an Observable stream that synchronously emits the integer
sequence 1 through 5. Implement a subscription to this Observable to consume and log
each value to the console upon emission.
*/
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var nums = (0, rxjs_1.of)(1, 2, 3, 4, 5);
nums.subscribe(function (ob) {
    console.log(ob);
});
