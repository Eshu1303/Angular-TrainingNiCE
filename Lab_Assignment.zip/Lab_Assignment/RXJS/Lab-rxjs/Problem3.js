"use strict";
/*
3. Interval Emission with Limited Take
Utilize the interval creation function from RxJS to generate an Observable that emits an
incrementing integer (starting from 0) every 1000 milliseconds (1 second). Use an
operator to limit the total number of emissions to only the first 5 values before the
Observable automatically completes.
*/
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var nums = (0, rxjs_1.interval)(1000).pipe((0, rxjs_1.take)(5));
nums.subscribe({
    next: function (res) {
        console.log(res);
    },
    complete: function () {
        console.log("Completed!!!");
    },
});
