/*
2. Data Transformation with Operators 
Generate an Observable that emits numbers 1 to 10. Apply a pipeline of RxJS operators 
to this stream to first filter the emissions, allowing only odd numbers to pass through. 
Then, use the map operator to transform each of these values by multiplying them by 
10. Finally, subscribe to the transformed Observable and log the resulting values (e.g., 
10, 30, 50, ...). 
*/
import { filter, map, of } from "rxjs";

let nums = of(1,2,3,4,5,6,7,8,9,10);

nums.pipe(filter(n=> n%2 !=0)).pipe(map(n => n*10)).subscribe(n => console.log(n));
