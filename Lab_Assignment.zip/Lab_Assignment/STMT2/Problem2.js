// Write a function sumAll that takes any number of arguments and returns their sum using rest parameters. 

function sumAll(...nums){
   let sum = 0;
   for(let num of nums){
    sum+=num;
   }
   return sum;
}

console.log(sumAll(10,20));