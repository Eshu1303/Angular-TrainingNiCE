// Merge two arrays arr1 = [1, 2, 3] and arr2 = [4, 5, 6] into a single array using the spread operator.

arr1 = [1, 2, 3]
arr2 = [4, 5, 6]
arr3 = [...arr1, ...arr2]

console.log(arr3);
