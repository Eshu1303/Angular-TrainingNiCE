//Extract firstName and lastName from the object: 
const user = { firstName: "John", lastName: "Doe", age: 30 };

let {firstName,lastName}= user;
console.log(firstName);
console.log(lastName);

