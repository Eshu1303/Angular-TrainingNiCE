// Rewrite the following string concatenation using template literals: 
const name = "Bob";
const age = 25;
console.log(`Name: ${name} , Age: ${age}`);
