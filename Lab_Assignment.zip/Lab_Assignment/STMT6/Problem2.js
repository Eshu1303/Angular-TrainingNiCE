// Create a multi-line string using template literals: 
const title = "My Story";
const content = "Once upon a time...";
console.log(`Title: ${title}\nContent: ${content}`);

// Expected output:
// Title: My Story
// Content: Once upon a time...